import React from 'react';

const page = () => {
  return (
    <div>
      main
      
    </div>
  );
};

export default page;