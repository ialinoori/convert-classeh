import React from 'react';

const page = () => {
    return (
        <div>
            داشبرد
            
        </div>
    );
};

export default page;