// "use client";

// import React, { useEffect, useState } from "react";
// // import MultiSelectDropdown from "../_components/muilti-select-dropdown/multi-seclet-dropdown";
// import DatePickerr from "../_components/datepicker/datepicker";
// import axios from "axios";
// import { Multiselect } from 'multiselect-react-dropdown';


// const Page = () => {
//   const [uploadedFiles, setUploadedFiles] = useState([]);
//   const [categorylist, setCcategorylist] = useState([]);
//   const [list, setList] = useState([]);

//   const Category = { options: [] };

//   const handleFileUpload = (e) => {
//     const files = e.target.files;
//     const fileList = Array.from(files);
//     setUploadedFiles(fileList);
//   };

//   const userData = localStorage.getItem("userData");

//   const headersAcademic = {
//     Authorization: JSON.parse(userData)?.token,
//   };
//   const now = parseInt(Date.now() / 1000);
//   const time = now;

//   useEffect(() => {
//     console.log(JSON.parse(userData)?.id);

//     const url = `/api/v3/Course_class?$filter={"andX":[{"eq": {"user.id":${1563}} },{"andX":[{"gt":{"school_class.academic_year.end_date":"${time}"}},{"lt":{"school_class.academic_year.start_date":"${time}"}}]}]}&$join=user,course,school_class,school_class.academic_year&$select=course.title,school_class.title`;
//     axios
//       .get(`https://mohammadfarhadi.classeh.ir/${url}`, {
//         headers: headersAcademic,
//       })
//       .then((data) => {
//         // console.log(data.data);

//         Object.keys(data.data).forEach((key) => {
//           const title_input = `${data.data[key].course.title} ${data.data[key].school_class.title}`;

//           Category.options.push({
//             mainID: data.data[key].id,
//             name: title_input,
//             id: data.data[key].school_class.id,
//             nameCourse: data.data[key].course.title,
//             nameClass: data.data[key].school_class.title,
//             idCourse: data.data[key].course.id,
//           });
//         });
//         // console.log(Category);

//         setCcategorylist(Category);
//       })
//       .catch((error) => {});
//   }, []);

//   const onSelect = (selectedList, selectedItem) => {
//     setList(prevState => [...prevState, selectedItem]);
//   };

//   const onRemove = (selectedList, removedItem) => {
//     console.log(selectedList);
//     console.log(removedItem);

//     setList([]);
//     selectedList.map(option => setList(prevState => [...prevState, option]));
//   };


//   console.log("ccccccccccccc", list);

//   return (
//     <div className="container mx-auto my-16">
//       <form className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
//         {/* <MultiSelectDropdown options={categorylist.options} /> */}
//         <Multiselect
//               options={categorylist.options}
//               placeholder="کلاس درس"
//               displayValue="name"
//               onSelect={onSelect}
//               onRemove={onRemove}
             
//             />

//         <div className="mb-4">
//           <label
//             className="block text-gray-700 text-sm font-bold mb-2"
//             htmlFor="input1"
//           >
//             عنوان
//           </label>
//           <input
//             className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//             id="input1"
//             type="text"
//             placeholder="عنوان تکلیف"
//           />
//         </div>

//         <div className="mb-4">
//           <label
//             className="block text-gray-700 text-sm font-bold mb-2"
//             htmlFor="input2"
//           >
//             متن
//           </label>
//           <input
//             className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
//             id="input2"
//             type="text"
//             placeholder="متن تکلیف"
//           />
//         </div>

//         <div className="mb-4">
//           <label
//             className="block text-gray-700 text-sm font-bold mb-2"
//             htmlFor="fileInput"
//           >
//             آپلود فایل‌ها
//           </label>
//           <input
//             type="file"
//             id="fileInput"
//             className="mb-2"
//             onChange={handleFileUpload}
//             multiple
//           />
//           <ul className="list-disc pl-4">
//             {uploadedFiles.map((file, index) => (
//               <li key={index}>{file.name}</li>
//             ))}
//           </ul>
//         </div>
//         <DatePickerr />
//       </form>
//     </div>
//   );
// };

// export default Page;

import React from 'react';

const page = () => {
  return (
    <div>
      
      
    </div>
  );
};

export default page;
